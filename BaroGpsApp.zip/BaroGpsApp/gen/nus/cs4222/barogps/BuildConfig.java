/** Automatically generated file. DO NOT MODIFY */
package nus.cs4222.barogps;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}